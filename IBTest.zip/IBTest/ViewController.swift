//
//  ViewController.swift
//  IBTest
//
//  Created by JeonIlHun on 18/09/2019.
//  Copyright © 2019 JeonIlHun. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    

    @IBOutlet var LabelText1: UILabel!
    @IBOutlet var LabelText2: UILabel!
    @IBOutlet var LabelText3: UILabel!
    @IBOutlet var LabelText4: UILabel!
    @IBOutlet var LabelText5: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func AtionButton1(_ sender: Any) {
        self.LabelText1.text = "전병훈"
        
    }
    @IBAction func AtionButton2(_ sender: Any) {
        self.LabelText2.text = "전병"
    }
    @IBAction func AtionButton3(_ sender: Any) {
        self.LabelText3.text = "삼겹살"
    }
    @IBAction func AtionButton4(_ sender: Any) {
        self.LabelText4.text = "사줘"
    }
    @IBAction func AtionButton5(_ sender: Any) {
        self.LabelText5.text = "한우도"
    }
    

}

